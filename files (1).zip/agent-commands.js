// ============================================
// AGENT COMMANDS FOR INDEX.JS
//
// 1. Add this import at the top of index.js:
//    const agent = require("./agentEngine")
//
// 2. Replace the NATURAL CONVERSATION section
//    at the bottom of index.js with the code below.
//    This makes normal chat go through the agent
//    brain so Jordan AI can take actions mid-conversation.
//
// 3. Add these commands BEFORE the natural conversation section.
// ============================================

  // ========================================
  // AGENT COMMANDS
  // ========================================

  // !agent <goal> - Run the agent with a specific goal
  if (content.startsWith("!agent")) {
    const goal = content.replace("!agent", "").trim()
    if (!goal) {
      await message.reply("Usage: `!agent <goal>`\n\nExamples:\n`!agent Check on all clients and handle any overdue follow-ups`\n`!agent Write and publish a blog post about AI for landscaping businesses`\n`!agent Review revenue and find the highest impact action for today`\n`!agent Onboard lakemurray as a new WordPress client and create their first blog post`")
      return
    }
    
    await message.reply(`🧠 **Agent starting...**\nGoal: ${goal}\n\nI'll update you as I work.`)
    
    const result = await agent.runAgent(goal, {
      maxSteps: 15,
      discordNotify: async (msg) => {
        try { await message.channel.send(msg) } catch (err) {}
      }
    })
    
    if (result.success) {
      await message.reply(`✅ **Agent finished** — ${result.steps} steps taken`)
    } else {
      await message.reply(`❌ Agent error: ${result.error}`)
    }
    return
  }

  // !agent status - Show agent status
  if (content === "!agent status") {
    const status = agent.getAgentStatus()
    await message.reply(
      `**🧠 Agent Status**\n\n` +
      `Running: ${status.isRunning ? "✅ Yes" : "❌ No"}\n` +
      `Current goal: ${status.currentGoal || "None"}\n` +
      `Runs today: ${status.runsToday}/${status.guardrails.maxDailyRuns}\n` +
      `Total runs: ${status.totalRuns}\n` +
      `Last run: ${status.lastRun || "Never"}\n` +
      `Max steps/run: ${status.guardrails.maxStepsPerRun}\n` +
      `Emails this hour: ${status.guardrails.emailsSentThisHour}/10`
    )
    return
  }


  // ========================================
  // NATURAL CONVERSATION (Agent-powered)
  // Jordan AI can now take ACTIONS during chat
  // ========================================
  
  // Only respond in the talk channel (or DMs)
  // This replaces the old openai.chat.completions section
  try {
    // Store conversation history per channel
    if (!conversationHistory.has(message.channel.id)) {
      conversationHistory.set(message.channel.id, [])
    }
    
    const history = conversationHistory.get(message.channel.id)
    
    // Keep last 10 messages for context
    if (history.length > 20) {
      history.splice(0, history.length - 20)
    }
    
    const result = await agent.agentChat(content, history)
    
    if (result.success && result.response) {
      // Update conversation history
      history.push({ role: "user", content })
      history.push({ role: "assistant", content: result.response })
      
      // Show what tools were used
      let toolNote = ""
      if (result.toolsUsed.length > 0) {
        const tools = result.toolsUsed.map(t => `${t.result === "success" ? "✅" : t.result === "needs_approval" ? "⚠️" : "❌"} ${t.tool}`).join(", ")
        toolNote = `\n\n_Tools used: ${tools}_`
      }
      
      await sendLongMessage(message.channel, result.response + toolNote)
    } else {
      await message.channel.send("I ran into an issue. Try again or use a specific !command.")
    }
    
  } catch (err) {
    console.log("Chat error:", err.message)
  }
